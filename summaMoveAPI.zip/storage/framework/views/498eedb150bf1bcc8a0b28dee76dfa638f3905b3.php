
<?php $__env->startSection('slot'); ?>
    <p>test</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\school\leerjaar 2\project\project 5\summaMove\Laravel\summaMoveAPI\resources\views/home.blade.php ENDPATH**/ ?>