<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>      
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    </head>
    <body>
        <?php echo $__env->make('layout.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="content">
            <div id="contentcontainer">
               
            </div>
        </div>
    </body>
</html><?php /**PATH C:\school\leerjaar 2\project\project 5\summaMove\Laravel\summaMoveAPI\resources\views/layout/app.blade.php ENDPATH**/ ?>