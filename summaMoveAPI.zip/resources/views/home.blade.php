@extends('layout.main')
@section('slot')
    <p>test</p>
@endsection